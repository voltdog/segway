% Load NXTway-GS Parameters

param_plant			% NXTway-GS Parameters and State-Space Matrix Calculation
param_controller	% Controller Parameters 
param_sim			% Simulation and Virtual Reality Parameters
