

This is a collection of python examples for CasADi 3.6.5.
Consult the documentation online at http://docs.casadi.org/v3.6.5/api/html/annotated.html.

To run an example vdp_single_shooting.py, you have several options:

a) fire up a terminal, navigate to this directory, and type "python vdp_single_shooting.py"
b) fire up a terminal, navigate to this directory, and type "ipython" and then "run vdp_single_shooting.py"
c) start spyder, open vdp_single_shooting.py and press "run".

    
