# Combine-MPC-and-MHE 
[![View Model Predictive Control and Moving Horizon Estimation on File Exchange](https://www.mathworks.com/matlabcentral/images/matlab-file-exchange.svg)](https://www.mathworks.com/matlabcentral/fileexchange/120738-model-predictive-control-and-moving-horizon-estimation)
This MATLAB code combines the Model Predictive Control (MPC) and Moving Horizon Estimation (MHE). This code is built based on Dr. Mohamed W. Mehrez's code (https://github.com/MMehrez/MPC-and-MHE-implementation-in-MATLAB-using-Casadi/tree/master/workshop_github)
